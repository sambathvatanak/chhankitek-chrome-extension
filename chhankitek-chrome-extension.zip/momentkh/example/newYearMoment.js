const moment = require('moment')
require('../momentkh')(moment)

console.log(moment.getKhNewYearMoment(2021))
